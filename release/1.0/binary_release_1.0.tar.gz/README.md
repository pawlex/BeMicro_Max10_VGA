# Device Programming files go here:

.sof is sram format.  It's larger, but programs nearly instantly, but is lost when the device loses power.

.pof is the compressed flash format, and is non-volatile.
